package com.parser.TextParser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.parser.OutputWriting.CSVWriter;
import com.parser.OutputWriting.XMLWriter;
import com.parser.domain.Sentence;

public class Textparser {
	static Scanner sentence;
	static final Logger logger = Logger.getLogger(Textparser.class);

	public static void main(String[] args) {
//Loading property file & getting input file
		try (InputStream input = Textparser.class.getClassLoader().getResourceAsStream("filelocations.properties")) {
			logger.info("Loaded properties from resource file");
			Properties prop = new Properties();
			prop.load(input);
//Reading inut file & breaking down sentences
			sentence = new Scanner(new File(prop.getProperty("input.file")));
			ArrayList<String> sentenceList = new ArrayList<String>();

			while (sentence.hasNextLine()) {
				sentenceList.add(sentence.nextLine());
			}
			logger.info("Read all the lines from file:" + prop.getProperty("input.file"));
//			calling parseSentence() to breakdown sentences into list of words
			Map<Sentence, List<String>> wordsMap = parseSentence(sentenceList);
			logger.info("Parsed the given text file successfully!!!");
			System.out.println("Select type of output format needed(xml/csv):");
			sentence = new Scanner(System.in);
			String format = sentence.next();
			sentence.close();
			if (format.equalsIgnoreCase("xml")) {
				logger.info("Output format XML selected");
				XMLWriter xmlWriter = new XMLWriter();
				xmlWriter.writeToXML(wordsMap);
			} else if (format.equalsIgnoreCase("csv")) {
				logger.info("Output format CSV selected");
				CSVWriter csvWriter = new CSVWriter();
				csvWriter.writeToCSV(wordsMap);
			} else {
				logger.info("Invalid output format!!");
			}
			sentence.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

	}

	private static Map<Sentence, List<String>> parseSentence(ArrayList<String> sentenceList) {
		logger.info("Breaking down sentences to words starts...");
		Map<Sentence, List<String>> wordsMap = new LinkedHashMap<>();
		String temp = "";
		int counter = 0;
		for (String s : sentenceList) {
			logger.info("sentence is: " + s);
			String[] s1 = s.split("(?<=[.!?])\\s*");
			sentenceList = new ArrayList<>(Arrays.asList(s1));
			if (!temp.isEmpty()) {
				sentenceList.set(0, temp.concat(sentenceList.get(0)));
				temp = "";
			}
			int lastIndex = sentenceList.size() - 1;
			String last = sentenceList.get(lastIndex);
			if (!(last.endsWith(".") || last.endsWith("?") || last.endsWith("!"))) {
				temp = sentenceList.get(lastIndex);
				sentenceList.remove(lastIndex);
			}

			for (String string : sentenceList) {
				counter++;
				Sentence sen = new Sentence(counter, string);
				List<String> words = Arrays.asList(string.split("[,\\s]"));
				words = words.stream().filter(c -> !c.isEmpty()).map(b->removeSpecialCharsAtStartAndEnd(b)).sorted(String::compareToIgnoreCase)
						.collect(Collectors.toList());
				words.stream().forEach(System.out::println);
				logger.info("words for it: " + words);
				wordsMap.put(sen, words);
			}
		}
		return wordsMap;
	}



	private static String removeSpecialCharsAtStartAndEnd(String str) {
		StringBuffer strbuffer;
		if (!Character.isLetterOrDigit(str.charAt(0))) {
			strbuffer = new StringBuffer(str);
			strbuffer.deleteCharAt(0);
			return strbuffer.toString();
		} else if (!Character.isLetterOrDigit(str.charAt(str.length() - 1))) {
			strbuffer = new StringBuffer(str);
			strbuffer.deleteCharAt(str.length() - 1);
			return strbuffer.toString();
		}

		return str;
	}
}
