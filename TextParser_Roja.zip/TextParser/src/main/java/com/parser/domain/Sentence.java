package com.parser.domain;

public class Sentence {
private int sentenceNum;
private String sentence;

public Sentence(int sentenceNum, String sentence) {
	super();
	this.sentenceNum = sentenceNum;
	this.sentence = sentence;
}

public int getSentenceNum() {
	return sentenceNum;
}

public void setSentenceNum(int sentenceNum) {
	this.sentenceNum = sentenceNum;
}

public String getSentence() {
	return sentence;
}

public void setSentence(String sentence) {
	this.sentence = sentence;
}

@Override
public String toString() {
	return "sentenceNum=" + sentenceNum + ", sentence=" + sentence;
}



}
