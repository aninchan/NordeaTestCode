package com.parser.OutputWriting;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.log4j.Logger;

import com.parser.domain.Sentence;

public class CSVWriter {
	
	static final Logger logger = Logger.getLogger(CSVWriter.class);

	public void writeToCSV(Map<Sentence, List<String>> map) {
		try (InputStream input = CSVWriter.class.getClassLoader().getResourceAsStream("filelocations.properties")) {
			Properties prop = new Properties();
			prop.load(input);
			logger.info("Loaded properties for input file location");
			int wordSize = map.values().stream().mapToInt(l -> l.size()).max().orElse(1);

			String[] headers = new String[wordSize + 1];
			for (int i = 1; i <= wordSize; i++)
				headers[i] = "Word " + i;

			try (FileWriter out = new FileWriter(prop.getProperty("output.csv.filepath"));
					CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT.withHeader(headers))) {
				map.entrySet().stream().forEach(e -> {
					try {
						printer.print("Sentence" + e.getKey().getSentenceNum());
						printer.printRecord(e.getValue());
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				});
				logger.info("Successfully transformed result to :"+prop.getProperty("output.csv.filepath"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
		} catch (IOException e2) {
			e2.printStackTrace();
		}
	}
}
