package com.parser.OutputWriting;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.parser.domain.Sentence;

public class XMLWriter {
	static final Logger logger = Logger.getLogger(XMLWriter.class);

	public void writeToXML(Map<Sentence, List<String>> map) {
		try (InputStream input = XMLWriter.class.getClassLoader().getResourceAsStream("filelocations.properties")) {
			Properties prop = new Properties();
			prop.load(input);
logger.info("Loaded properties for input file location");
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();

			Document document = documentBuilder.newDocument();
			Element text = document.createElement("text");
			document.appendChild(text);

			for (Map.Entry<Sentence, List<String>> entry : map.entrySet()) {
				Element sentence = document.createElement("sentence");
				text.appendChild(sentence);
				for (String w : entry.getValue()) {
					Element word = document.createElement("word");
					word.appendChild(document.createTextNode(w));
					sentence.appendChild(word);
				}
			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(document);
			StreamResult destination = new StreamResult(new File(prop.getProperty("output.xml.filepath")));

			transformer.transform(source, destination);
			logger.info("Successfully transformed result to :"+destination.getSystemId());

		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
}
