
Prerequisites to use this TextParser application:
1.Specify your input & output file path in filelocations.properties
2.Specify your log directory in log4j.properties file---log4j.appender.file.File
3.Once ran this application, please fill your output format choice in console.