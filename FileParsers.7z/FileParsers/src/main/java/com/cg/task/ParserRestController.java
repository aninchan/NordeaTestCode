package com.cg.task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.task.Util.ParserUtil;
import com.cg.task.exception.FileTypeException;
import com.cg.task.exception.ResourceNotFoundException;
import com.cg.task.model.InputFileDetails;
import com.cg.task.service.ParseService;

@RestController
@RequestMapping("Parser")
public class ParserRestController {
	
	 private static final Logger LOGGER = LoggerFactory.getLogger(ParserRestController.class);
	 
		
		  @Autowired 
		  private ParseService parseService;
		  /**
		     * The method is to to call the service parser methods to convert the csv file formate
		     * @param path
		     * @param type
		     * 
		     */ 
	 	 @RequestMapping("converter")
	    public String converterType(@RequestBody InputFileDetails details) throws Exception {
	        LOGGER.info("In converterType");
	        if(!details.getFileName().isEmpty()) {
	        	LOGGER.info("Input file name :"+details.getFileName());
	        	  	if(details.getOutputFiletType() !=ParserUtil.csvFileFormate) {
	        	  		LOGGER.info("outputFile file type extension :"+details.getOutputFiletType());
	               return parseService.createFile(details.getFileName(), details.getOutputFiletType());
	              
	           }else {
	        	   throw new FileTypeException(ParserUtil.FileTypeException);   
	           }
	       }else {
	    	 throw new ResourceNotFoundException(ParserUtil.resourceNotFoundException);
	       }
	        
	        
	    }

}
