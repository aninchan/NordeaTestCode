package com.cg.task.exception;

public class FileTypeException extends Exception {
	public FileTypeException() {
        super();
    }

    public FileTypeException(String message) {
        super(message);
    }

    public FileTypeException(String message, Exception cause) {
        super(message, cause);
    }
}
