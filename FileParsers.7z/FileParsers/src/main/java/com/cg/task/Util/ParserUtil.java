package com.cg.task.Util;

public class ParserUtil {
	
	public static final String response="CSV file generated";
	public static final String csvFileFormate="csv";
	public static final String resourceNotFoundException="Parsing file is empty";
	public static final String FileTypeException="Other than csv type as an input for output file.";

}
