package com.cg.task.service.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.cg.task.Util.ParserUtil;
import com.cg.task.service.ParseService;

@Service
public class ParserServiceImpl implements ParseService {
	static String[] SENTENCE;

	private static final Logger LOGGER = LoggerFactory.getLogger(ParserServiceImpl.class);

	@Override
	public String createFile(String input, String outputFiletype) throws IOException {
		ArrayList<String> lines = new ArrayList<>();
		int lineNumber = 0;
		try {

			FileReader fr = new FileReader(input);
			BufferedReader br = new BufferedReader(fr);
			ArrayList<String> sentenceList = new ArrayList<String>();
			Scanner sentence = new Scanner(new File(input));
			String line = null;
			while ((line = br.readLine()) != null) {
				sentenceList.add(line);
			}

			sentence.close();

			String[] sentenceArray = sentenceList.toArray(new String[sentenceList.size()]);

			for (int r = 0; r < sentenceArray.length; r++) {

				SENTENCE = sentenceArray[r].split("(?<=[.!?])\\s*");
				for (int i = 0; i < SENTENCE.length; i++) {

					lines.add(SENTENCE[i]);

				}
			}

		} catch (Exception e) {

		}
		List<String> newList = null;
		newList = getSentences(lines);
		newList = getSentences(newList);
		newList = removeSpecialCharacters(newList);
		writeFile(input, newList, outputFiletype);
		
		return ParserUtil.response;
	}

	public void writeFile(String input, List newList, String fileType) throws IOException {

		BufferedWriter fs = new BufferedWriter(
				new FileWriter((input.substring(0, input.lastIndexOf("/")) + "/" + fileType)));
		List<List<String>> sentenceList = getWords(newList);
		int counter = 1;
		for (List<String> list : sentenceList) {

			String commaseparatedSentence = "";

			fs.write("Sentence" + counter + ",");
			for (String words : list) {
				if (words.length() != 0)
					commaseparatedSentence = commaseparatedSentence + words + ",";

			}
			fs.write(commaseparatedSentence);
			fs.newLine();
			counter++;
			fs.flush();

		}
	}

	public static List<List<String>> getWords(List<String> newList) {
		List<List<String>> sentenceList = new ArrayList<List<String>>();

		for (String string : newList) {

			string = string.replace(",", " ");
			string = string.replace("  ", " ");
			string = string.replace(":", "");

			String[] splitWords = string.split(" ");
			ArrayList<String> words = new ArrayList<String>();
			for (String string2 : splitWords) {
				String[] newSplit = string2.split("	");
				if (newSplit.length != 0) {
					for (String string3 : newSplit) {
						words.add(string3);
					}

				}

			}
			List<String> sortedList = words.stream().sorted().collect(Collectors.toList());
			sentenceList.add(sortedList);

		}
		return sentenceList;
	}

	public static List<String> removeSpecialCharacters(List<String> list) {
		List<String> newList = list.stream().map(e -> e.substring(0, e.length() - 1)).collect(Collectors.toList());

		return newList;
	}

	public static List<String> getSentences(List<String> lines) {
		int lineNumber = 0;
		ArrayList<String> newList = new ArrayList<String>();

		for (int i = 0; i < lines.size(); i++) {
			if (lineNumber >= lines.size()) {
				break;
			}
			String str = lines.get(lineNumber);
			boolean flag = false;
			if (str.contains(".") || str.contains("!") || str.contains("?")) {
				flag = true;
				if (str.contains("Mr.")) {
					flag = false;
				}

				if (flag == true) {

					newList.add(str);
					lineNumber++;
				}
			}

			if (flag == false) {

				newList.add(str + lines.get(lineNumber + 1));
				lineNumber = lineNumber + 2;

			}

		}
		return newList;

	}

}
