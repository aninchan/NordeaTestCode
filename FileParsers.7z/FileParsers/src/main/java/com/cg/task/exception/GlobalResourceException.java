package com.cg.task.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalResourceException {

	@ExceptionHandler(ResourceNotFoundException.class)
	    public ResponseEntity<String> handleResourceNotFoundException(ResourceNotFoundException resourceNotFoundException) {

	           return new ResponseEntity(resourceNotFoundException.getMessage(), HttpStatus.BAD_REQUEST);

	    }
	@ExceptionHandler(FileTypeException.class)
    public ResponseEntity<String> handleResourceNotFoundException(FileTypeException fileTypeException) {

           return new ResponseEntity(fileTypeException.getMessage(), HttpStatus.BAD_REQUEST);

    }
}
