package com.cg.task.service;

/**
 * @author 
 */
public interface ParseService {
	
	/**
     * The method is to parse the file and create csv file
     * @param path
     * @param type
     * 
     */
	public String  createFile(String path,String type)throws Exception;

}
