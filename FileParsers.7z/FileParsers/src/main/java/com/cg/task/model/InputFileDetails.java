package com.cg.task.model;

public class InputFileDetails {
	String fileName;
	String outputFiletType;
	
	public InputFileDetails() {}
	
	public InputFileDetails(String fileName, String outputFiletType) {
		super();
		this.fileName = fileName;
		this.outputFiletType = outputFiletType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getOutputFiletType() {
		return outputFiletType;
	}

	public void setOutputFiletType(String outputFiletType) {
		this.outputFiletType = outputFiletType;
	}
	
	
	

}
