package com.cg.task;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.task.Util.ParserUtil;
import com.cg.task.service.ParseService;

@SpringBootTest
class FileParsersApplicationTests {

	 @Autowired 
	  private ParseService parseService;
	
	@Test
	void parseFileLoads() throws  Exception {
		String expected=parseService.createFile("C:/small.in","csv");
		assertEquals(expected, ParserUtil.response);
		
	}

}
