In order to execute the jar file- You must have Java installed on your system
Please follow below process to execute the jar file:
- Run below command

java -jar wordsParser.jar "inputfilepath" "ouputfilepath"

* In above command enter inputfilepath along with file name.For example if your file input.txt is in "D:\Input files" 
  then please enter inputfile path as "D:\Input Files\input.txt"

* For outputfilepath enter only folder where you want to save output files
  For example if you want to save output file in "D:\Output Files" then enter the path only