package com.nordea.eval.filereadwrite;

import java.io.File;
import java.util.List;

import com.nordea.eval.filereadwrite.domain.Sentence;

import junit.framework.TestCase;

public class CSVFileWriteTest extends TestCase {

	public void testProcessFile() {
		FileRead fr = new FileRead();
		String filePath = "C:\\\\nordea\\\\cgh";
		String fileName = "small.in";
		String fileToRead = filePath+"\\"+fileName;
		String fileToWrite = filePath+"small.xml";
		String type = "CSV";
		try {
			List<Sentence> sentenceList = fr.readFile(fileToRead);
			FileWriterFactory factory = new FileWriterFactory();
			FileWriter fw = factory.getFileWriter(type);
			fw.processFile(sentenceList, fileToWrite);
			File file = new File(fileToRead);
			assertTrue(file.exists());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
