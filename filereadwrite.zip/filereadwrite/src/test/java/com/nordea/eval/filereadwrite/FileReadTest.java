package com.nordea.eval.filereadwrite;

import java.util.List;

import com.nordea.eval.filereadwrite.domain.Sentence;

import junit.framework.TestCase;

public class FileReadTest extends TestCase {

	public void testReadFile() {
		//fail("Not yet implemented");
		FileRead fr = new FileRead();
		String filePath = "C:\\\\nordea\\\\cgh";
		String fileName = "small.in";
		String fileToRead = filePath+"\\"+fileName;
		
		try {
			List<Sentence> sentenceList = fr.readFile(fileToRead);
			assertTrue(sentenceList.size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
