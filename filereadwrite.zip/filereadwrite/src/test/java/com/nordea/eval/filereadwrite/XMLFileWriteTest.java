/**
 * 
 */
package com.nordea.eval.filereadwrite;

import java.io.File;
import java.util.List;

import com.nordea.eval.filereadwrite.domain.Sentence;

import junit.framework.TestCase;

/**
 * @author garamasw
 *
 */
public class XMLFileWriteTest extends TestCase {

	/**
	 * Test method for {@link com.nordea.eval.filereadwrite.XMLFileWriter#processFile(java.util.List, java.lang.String)}.
	 */
	public void testProcessFile() {
		FileRead fr = new FileRead();
		String filePath = "C:\\\\nordea\\\\cgh";
		String fileName = "small.in";
		String fileToRead = filePath+"\\"+fileName;
		String fileToWrite = filePath+"small.xml";
		String type = "XML";
		try {
			List<Sentence> sentenceList = fr.readFile(fileToRead);
			FileWriterFactory factory = new FileWriterFactory();
			FileWriter fw = factory.getFileWriter(type);
			fw.processFile(sentenceList, fileToWrite);
			File file = new File(fileToRead);
			assertTrue(file.exists());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
