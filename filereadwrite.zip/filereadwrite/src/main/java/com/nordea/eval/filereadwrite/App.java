package com.nordea.eval.filereadwrite;

import java.io.IOException;
import java.util.List;

import com.nordea.eval.filereadwrite.domain.Sentence;

/**
 * @garamasw
 * Main class to read from file and write into CSV or XML
 * Provide Arguments for input file name and path
 * output filetype, and output file path with name
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException, Exception
    {
        String filePath = args[0];
        String fileName = args[1];
        System.out.println(fileName);
        String outputFileType = args[2];
        String fileToRead = filePath+"\\"+fileName;
        String fileNameToWrite = args[3];
        System.out.println("File to Read "+fileToRead);
        FileRead fileRead = new FileRead();
        List<Sentence> sentenceList = fileRead.readFile(fileToRead);
        
        FileWriterFactory factory = new FileWriterFactory();
        FileWriter fw = factory.getFileWriter(outputFileType);
        fw.processFile(sentenceList, fileNameToWrite);
    }
}
