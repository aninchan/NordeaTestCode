/**
 * 
 */
package com.nordea.eval.filereadwrite;

import java.util.ArrayList;
import java.util.List;

import com.nordea.eval.filereadwrite.domain.Sentence;
import com.nordea.eval.filereadwrite.domain.Words;
import com.opencsv.CSVWriter;

/**
 * @author garamasw
 * CSVFileWriter required for writing the data read
 * from in file into a CSV file
 * The file extends FileWriter and overrides
 * the processFile method
 *
 */
public class CSVFileWriter extends FileWriter {

	private int wordSize = 1;

	/**
	 * Method to read and write the data to a CSV file
	 * @param List<Sentence> sentenceList which has been converted
	 * @param String filename the name and path of the file
	 */
	@Override
	public void processFile(List<Sentence> sentenceList, String fileName) throws Exception {
		int index = 1;
		int sentenceListSize = sentenceList.size() + 1;
		List<String[]> strArrList = new ArrayList(sentenceListSize);
		for (Sentence sentence : sentenceList) {
			List<Words> wordsList = sentence.getWordsList();
			Words words = new Words();
			String sentWord = "Sentence  " + index;
			words.setWord(sentWord);
			wordsList.add(0, words);
			int wordListSize = wordsList.size();
			wordSize = wordListSize > wordSize ? wordsList.size() : wordListSize;
			String[] wordStrArr = wordsList.stream().map(x -> x.getWord()).toArray(String[]::new);
			strArrList.add(wordStrArr);
			index++;

		}
		String word[] = new String[wordSize];
		for (int i = 1; i <= wordSize; i++) {
			int arrayIndex = i-1;
			word[arrayIndex] = "word " + i;
		}
		System.out.println(word);
		strArrList.add(0, word);
		CSVWriter writer = new CSVWriter(new java.io.FileWriter(fileName));
		writer.writeAll(strArrList);
		writer.flush();
		writer.close();
	}

}
