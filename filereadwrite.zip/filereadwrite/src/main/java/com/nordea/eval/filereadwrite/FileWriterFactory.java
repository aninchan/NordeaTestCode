/**
 * 
 */
package com.nordea.eval.filereadwrite;

/**
 * @author garamasw
 * Factory class to identify the Source of File Writer
 * 
 *
 */
public class FileWriterFactory {

	/**
	 * method to identify the appropriate FileWriter
	 * @param fileType
	 * @return FileWriter implementation
	 */
	public FileWriter getFileWriter(String fileType) {
		FileWriter fw = null;
		fileType = fileType == null ? "" : fileType.trim().toUpperCase();
		switch (fileType) {
		case "XML":
			fw = new XMLFileWriter();
			break;
		case "CSV":
			fw = new CSVFileWriter();
			break;
			
		}
		return fw;
	}

}
