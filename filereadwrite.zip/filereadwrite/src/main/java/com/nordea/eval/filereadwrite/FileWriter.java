/**
 * 
 */
package com.nordea.eval.filereadwrite;

import java.util.List;

import com.nordea.eval.filereadwrite.domain.Sentence;

/**
 * @author garamasw Abstract class to write into specified source
 */
public abstract class FileWriter {

	/**
	 * Abstrac method to be implemented by SPecific source like XML/CSV
	 * 
	 * @param        List<Sentence> sentenceList Sentence Domain Collection
	 * @param String fileNamme the file with path
	 */
	public abstract void processFile(List<Sentence> sentenceList, String fileNamme) throws Exception;

}
