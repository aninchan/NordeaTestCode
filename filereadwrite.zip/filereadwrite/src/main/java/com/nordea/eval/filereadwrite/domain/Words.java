/**
 * 
 */
package com.nordea.eval.filereadwrite.domain;

/**
 * @author garamasw
 * Value Object for Words
 *
 */
public class Words {

	private String word;

	/**
	 * @return the word
	 */
	public String getWord() {
		return word;
	}

	/**
	 * @param word the word to set
	 */
	public void setWord(String word) {
		this.word = word;
	}
	
}
