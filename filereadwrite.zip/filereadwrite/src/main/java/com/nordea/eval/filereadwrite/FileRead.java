/**
 * 
 */
package com.nordea.eval.filereadwrite;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.nordea.eval.filereadwrite.domain.Sentence;
import com.nordea.eval.filereadwrite.domain.Words;

/**
 * @author garamasw
 *
 */
public class FileRead {

	/**
	 * Method to read the data from .in file
	 * and wrap into a Sentence domain
	 * @param fileName fileName with path
	 * @return List<Sentence>
	 * @throws IOException
	 * @throws Exception
	 */
	public List<Sentence> readFile(String fileName) throws IOException, Exception {
		try (Stream<String> stream = Files.lines(Paths.get(fileName))) {
			//stream.filter(x -> (x.contains(","))).forEach(System.out::println);
			List<Sentence> sentenceList = stream.map(x -> getSentence(x)).collect(Collectors.toList());
			return sentenceList;
		} catch (IOException e) {
			System.out.println("IOException");
			System.out.println(e.getMessage());
			throw e;
		} catch (Exception e) {
			System.out.println("Exception");
			System.out.println(e.getMessage());
			throw e;
		}
	}

	/**
	 * Method to wrap up the line of a file
	 * into a Sentence
	 * @param str
	 * @return
	 */
	private Sentence getSentence(String str) {
		String[] arrString = str.split(" ");
		List<Words> wordsList = Arrays.asList(arrString).stream().sorted().map(x -> getWords(x)).collect(Collectors.toList());
		wordsList.stream().map(x->x.getWord()).forEach(System.out::println);
		Sentence sentence = new Sentence();
		sentence.setWordsList(wordsList);
		return sentence;
	}

	/**
	 * Method to wrap up the line of a file
	 * into a Word
	 * @param str
	 * @return
	 */
	private Words getWords(String word) {
		Words words = new Words();
		words.setWord(word.trim());
		return words;
	}

}
