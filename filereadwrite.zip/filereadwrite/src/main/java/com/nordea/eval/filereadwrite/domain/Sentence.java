/**
 * 
 */
package com.nordea.eval.filereadwrite.domain;

import java.util.List;

/**
 * @author garamasw
 * Value Object for Sentence
 *
 */
public class Sentence {
	
	private List<Words> wordsList;

	/**
	 * @return the wordsList
	 */
	public List<Words> getWordsList() {
		return wordsList;
	}

	/**
	 * @param wordsList the wordsList to set
	 */
	public void setWordsList(List<Words> wordsList) {
		this.wordsList = wordsList;
	}

}
