/**
 * 
 */
package com.nordea.eval.filereadwrite;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.nordea.eval.filereadwrite.domain.Sentence;
import com.nordea.eval.filereadwrite.domain.Words;

/**
 * @author garamasw
 *
 */
public class XMLFileWriter extends FileWriter {

	/**
	 * @author garamasw CSVFileWriter required for writing the data read from in
	 *         file into a CSV file The file extends FileWriter and overrides the
	 *         processFile method
	 *
	 */

	@Override
	public void processFile(List<Sentence> sentenceList, String fileName) throws Exception {

		String xml = sentenceList.stream().map(x -> generateXMLString(x)).collect(Collectors.joining(""));
		String text = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" + "<text>" + xml + "</text>";
		System.out.println(text);
		writeFile(text, fileName);

	}

	/**
	 * method to generate the XML String from the Sentence Object
	 * @param sentence
	 * @return String
	 */

	private String generateXMLString(Sentence sentence) {
		List<Words> wordList = sentence.getWordsList();

		String word = wordList.stream().map(x -> "<word>" + x.getWord() + "</word>")
				.filter(x -> !x.equals("<word></word>")).collect(Collectors.joining(""));
		String sentenceString = "<sentence>" + word + "</sentence>";

		return sentenceString;
	}

	/**
	 * method to write the XML String into XML file
	 * @param sentence
	 * @return String
	 */
	public void writeFile(String xmlFile, String path) throws SAXException, IOException, ParserConfigurationException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		org.w3c.dom.Document doc = builder.parse(new InputSource(new StringReader(xmlFile)));
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer;
		try {
			transformer = tf.newTransformer();
			FileOutputStream outStream = new FileOutputStream(new File(path));
			transformer.transform(new DOMSource(doc), new StreamResult(outStream));
		} catch (TransformerException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
