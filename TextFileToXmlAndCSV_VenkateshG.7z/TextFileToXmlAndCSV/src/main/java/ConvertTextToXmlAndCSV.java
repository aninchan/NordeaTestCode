import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.Interview.model.Sentence;
import com.thoughtworks.xstream.XStream;

public class ConvertTextToXmlAndCSV {

	public static void main(String[] args) throws Exception {

		String filePath = "E:\\small.in";

		List<Sentence> sentenceList = convertTextFileToSentences(filePath);

		XStream xstream = new XStream();
		xstream.alias("text", Sentence.class);
		xstream.alias("sentence", ArrayList.class);
		xstream.alias("word", String.class);
		String xml = xstream.toXML(sentenceList);

		writeToXML(xml);
		writeToCSV(sentenceList);
	}

	private static List<Sentence> convertTextFileToSentences(String filePath) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(new File(filePath)));
		String st;
		StringBuilder sb = new StringBuilder();
		while ((st = br.readLine()) != null) {
			sb.append(st);
		}

		br.close();

		String data = sb.toString();

		List<String> sentenceList = Arrays.asList(data.split("(?<=[.!?])\\s*"));

		// converts list of Strings to List of Sentence
		List<Sentence> sentences = new ArrayList<>();
		List<String> words;
		for (String sentence : sentenceList) {
			words = Arrays.asList(sentence.split(" "));
			Collections.sort(words);
			sentences.add(new Sentence(words));
		}
		return sentences;
	}
	
	public static void writeToXML(String xml) {
		String whereWrite = "E:/small.xml";

		try {
			FileWriter fw = new FileWriter(whereWrite, false);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bw);
			pw.println(xml);
			pw.flush();
			pw.close();

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void writeToCSV(List<Sentence> sentences) {
		String whereWrite = "E:/small.csv";

		try {
			FileWriter fw = new FileWriter(whereWrite, false);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bw);
			int index = 1;
			for (Sentence sent : sentences) {
				pw.println("sentence" + index + "," + sent.getWordsInSentence());
				index++;
			}
			pw.flush();
			pw.close();

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
