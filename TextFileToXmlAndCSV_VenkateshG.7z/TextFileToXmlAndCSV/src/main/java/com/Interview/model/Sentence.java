package com.Interview.model;

import java.util.List;

public class Sentence {

	private List<String> sentence;

	public Sentence() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sentence(List<String> sentence) {
		super();
		this.sentence = sentence;
	}

	public List<String> getWordsInSentence() {
		return sentence;
	}

	public void setWordsInSentence(List<String> sentence) {
		this.sentence = sentence;
	}

}
